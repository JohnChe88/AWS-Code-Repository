import json


def lambda_handler(event, context):
    """
    Main entry point in the Lambda Function
    Event sample is in event.json in repo
    Simple function that capture the put events
    in a S3 bucket and invoke the Lambda
    """

    # parsing throught the event and getting the S3 bucket name
    bucket = event['Records'][0]['s3']['bucket']['name']

    return {
        "statusCode": 200,
        "body": json.dumps({
            "BucketName": bucket,
            "status": "it worked"
        })
    }
